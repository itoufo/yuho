/**
 * xopt Chrome Extension — Background Service Worker
 * Handles API communication with xopt-api-v1
 */

const API_URL =
  "https://abhrgewzglubansbyitm.supabase.co/functions/v1/xopt-api-v1";

const ERROR_MESSAGES = {
  401: "APIキーが無効です。設定を確認してください",
  402: "クレジット不足です。xoptでチャージしてください",
  403: "権限不足です。APIキーの権限を確認してください",
  429: "レート制限に達しました。しばらくお待ちください",
  500: "サーバーエラーが発生しました。しばらく後に再試行してください",
  502: "サーバーエラーが発生しました。しばらく後に再試行してください",
};

// ---- API call with retry ----

async function callXoptApi(apiKey, body, retries = 3) {
  let lastError;

  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        const code = res.status;
        // Don't retry client errors (4xx)
        if (code >= 400 && code < 500) {
          return {
            success: false,
            error: ERROR_MESSAGES[code] || data?.error?.message || `エラー (${code})`,
            code,
          };
        }
        // Retry server errors
        lastError = ERROR_MESSAGES[code] || data?.error?.message || `サーバーエラー (${code})`;
        if (attempt < retries - 1) {
          await sleep(Math.pow(2, attempt) * 1000);
          continue;
        }
      }

      if (data.error) {
        return {
          success: false,
          error: data.error.message || "不明なエラー",
          code: data.error.code,
        };
      }

      return { success: true, data };
    } catch (e) {
      lastError = "ネットワークエラー。接続を確認してください";
      if (attempt < retries - 1) {
        await sleep(Math.pow(2, attempt) * 1000);
      }
    }
  }

  return { success: false, error: lastError, code: "NETWORK_ERROR" };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---- Get stored API key ----

async function getApiKey() {
  const result = await chrome.storage.local.get(["xopt_api_key"]);
  return result.xopt_api_key || null;
}

// ---- Message handler ----

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse);
  return true; // Keep channel open for async response
});

async function handleMessage(message) {
  const { action } = message;

  if (action === "getApiKey") {
    const key = await getApiKey();
    return { success: !!key, hasKey: !!key };
  }

  if (action === "testConnection") {
    const apiKey = message.apiKey;
    if (!apiKey) {
      return { success: false, error: "APIキーが入力されていません" };
    }
    const result = await callXoptApi(apiKey, {
      action: "profile",
      method: "GET",
    });
    return result;
  }

  // All generation actions require API key
  const apiKey = await getApiKey();
  if (!apiKey) {
    return {
      success: false,
      error: "APIキーが設定されていません。拡張機能の設定でAPIキーを入力してください。",
    };
  }

  switch (action) {
    case "generateReply": {
      const body = {
        action: "post",
        mode: "ai",
        platform: "x",
        theme: "返信",
        customInstructions: `以下のツイートへの返信を生成してください。元ツイートの内容に合った自然な返信を作成してください。投稿本文のみを出力してください。\n\n元ツイート:\n${message.tweetText}`,
      };
      return callXoptApi(apiKey, body);
    }

    case "generateQuote": {
      const body = {
        action: "post",
        mode: "ai",
        platform: "x",
        theme: "引用コメント",
        customInstructions: `以下のツイートへの引用コメントを生成してください。独自の視点や付加価値のあるコメントを作成してください。投稿本文のみを出力してください。\n\n元ツイート:\n${message.tweetText}`,
      };
      return callXoptApi(apiKey, body);
    }

    case "generatePost": {
      const body = {
        action: "post",
        mode: "ai",
        platform: "x",
        theme: message.theme,
        category: message.category || "useful",
        tone: message.tone || "auto",
      };
      return callXoptApi(apiKey, body);
    }

    default:
      return { success: false, error: `不明なアクション: ${action}` };
  }
}
