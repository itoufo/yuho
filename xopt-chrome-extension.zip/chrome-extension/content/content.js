/**
 * xopt Chrome Extension — Content Script
 * Injects AI reply/quote/post buttons into X (Twitter) UI
 */

(function () {
  "use strict";

  // Prevent double injection
  if (window.__xopt_injected) return;
  window.__xopt_injected = true;

  // ---- Constants ----

  const SELECTORS = {
    tweet: '[data-testid="tweet"]',
    tweetText: '[data-testid="tweetText"]',
    replyButton: '[data-testid="reply"]',
    retweetButton: '[data-testid="retweet"]',
    actionBar: 'div[role="group"]',
    composeArea: '[data-testid="tweetTextarea_0"]',
    postButton: '[data-testid="tweetButtonInline"]',
  };

  const XOPT_BLUE = "rgb(29, 155, 240)";

  // ---- Dark mode detection ----

  function isDarkMode() {
    const bg = getComputedStyle(document.documentElement).backgroundColor;
    if (!bg || bg === "rgba(0, 0, 0, 0)") {
      const bodyBg = getComputedStyle(document.body).backgroundColor;
      if (bodyBg) {
        const match = bodyBg.match(/\d+/g);
        if (match) {
          const brightness =
            (parseInt(match[0]) + parseInt(match[1]) + parseInt(match[2])) / 3;
          return brightness < 128;
        }
      }
    }
    const match = bg.match(/\d+/g);
    if (match) {
      const brightness =
        (parseInt(match[0]) + parseInt(match[1]) + parseInt(match[2])) / 3;
      return brightness < 128;
    }
    return false;
  }

  // ---- SVG Icons ----

  const XOPT_ICON_SVG = `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-1-1 3.5-3.5L10 9l1-1 4.5 4.5L11 17zm3-1l1-1-3.5-3.5L16 9l-1-1-4.5 4.5L15 17z"/></svg>`;

  const BOLT_ICON_SVG = `<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66.19-.34.05-.08.07-.12C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.49 0 .56.33.47.51l-.07.15C12.96 17.55 11 21 11 21z"/></svg>`;

  // ---- Toast notification ----

  function showToast(message, type = "success") {
    const existing = document.querySelector(".xopt-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.className = `xopt-toast xopt-toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add("xopt-toast-visible"));

    setTimeout(() => {
      toast.classList.remove("xopt-toast-visible");
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ---- Text insertion into X compose area ----

  async function insertTextIntoCompose(text) {
    // Wait for compose area to appear
    let composeArea = null;
    for (let i = 0; i < 30; i++) {
      composeArea = document.querySelector(SELECTORS.composeArea);
      if (composeArea) break;
      await sleep(100);
    }
    if (!composeArea) {
      showToast("入力欄が見つかりません", "error");
      return false;
    }

    // Focus the compose area
    composeArea.focus();
    await sleep(100);

    // Method 1: Clipboard API paste
    try {
      const clipboardData = new DataTransfer();
      clipboardData.setData("text/plain", text);
      const pasteEvent = new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        clipboardData: clipboardData,
      });
      composeArea.dispatchEvent(pasteEvent);

      // Verify text was inserted
      await sleep(200);
      if (composeArea.textContent && composeArea.textContent.includes(text.substring(0, 20))) {
        return true;
      }
    } catch (e) {
      // Fall through to next method
    }

    // Method 2: execCommand insertText
    try {
      document.execCommand("insertText", false, text);
      await sleep(200);
      if (composeArea.textContent && composeArea.textContent.includes(text.substring(0, 20))) {
        return true;
      }
    } catch (e) {
      // Fall through
    }

    // Method 3: InputEvent dispatch
    try {
      const inputEvent = new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text,
      });
      composeArea.dispatchEvent(inputEvent);
      await sleep(200);
      if (composeArea.textContent && composeArea.textContent.includes(text.substring(0, 20))) {
        return true;
      }
    } catch (e) {
      // Fall through
    }

    // Method 4: Direct text node manipulation + events
    try {
      const textNode = document.createTextNode(text);
      const editableDiv =
        composeArea.querySelector('[contenteditable="true"]') || composeArea;

      // Clear placeholder
      const placeholder = editableDiv.querySelector(
        '[data-testid="tweetTextarea_0_label"]'
      );
      if (placeholder) placeholder.style.display = "none";

      // Find or create the text container
      let span = editableDiv.querySelector("span[data-text]");
      if (!span) {
        span = editableDiv.querySelector("span") || editableDiv;
      }
      span.textContent = "";
      span.appendChild(textNode);

      // Fire React-compatible events
      const nativeInputEvent = new Event("input", { bubbles: true });
      editableDiv.dispatchEvent(nativeInputEvent);
      editableDiv.dispatchEvent(new Event("change", { bubbles: true }));

      return true;
    } catch (e) {
      showToast("テキスト挿入に失敗しました。手動でコピペしてください。", "error");
      // Copy to clipboard as fallback
      try {
        await navigator.clipboard.writeText(text);
        showToast("クリップボードにコピーしました", "info");
      } catch (_) {}
      return false;
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // ---- Create xopt action button for tweets ----

  function createTweetButton(label, onClick) {
    const btn = document.createElement("button");
    btn.className = "xopt-tweet-btn";
    btn.setAttribute("aria-label", label);
    btn.innerHTML = `<span class="xopt-tweet-btn-icon">${XOPT_ICON_SVG}</span><span class="xopt-tweet-btn-label">${label}</span>`;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      onClick(btn);
    });
    return btn;
  }

  // ---- Extract tweet text from a tweet element ----

  function getTweetText(tweetEl) {
    const textEl = tweetEl.querySelector(SELECTORS.tweetText);
    return textEl ? textEl.textContent.trim() : "";
  }

  // ---- Handle reply generation ----

  async function handleReply(btn, tweetEl) {
    const tweetText = getTweetText(tweetEl);
    if (!tweetText) {
      showToast("ツイートテキストが取得できません", "error");
      return;
    }

    btn.classList.add("xopt-loading");
    btn.disabled = true;

    // Click native reply button to open compose area
    const replyBtn = tweetEl.querySelector(SELECTORS.replyButton);
    if (replyBtn) {
      replyBtn.click();
      await sleep(500);
    }

    try {
      const result = await chrome.runtime.sendMessage({
        action: "generateReply",
        tweetText,
      });

      if (result.success) {
        const content = result.data?.data?.content || "";
        if (content) {
          await insertTextIntoCompose(content);
          showToast("返信を生成しました", "success");
        } else {
          showToast("返信の生成結果が空です", "error");
        }
      } else {
        showToast(result.error || "生成に失敗しました", "error");
      }
    } catch (e) {
      showToast("エラーが発生しました", "error");
    } finally {
      btn.classList.remove("xopt-loading");
      btn.disabled = false;
    }
  }

  // ---- Handle quote generation ----

  async function handleQuote(btn, tweetEl) {
    const tweetText = getTweetText(tweetEl);
    if (!tweetText) {
      showToast("ツイートテキストが取得できません", "error");
      return;
    }

    btn.classList.add("xopt-loading");
    btn.disabled = true;

    // Click native retweet button, then quote
    const retweetBtn = tweetEl.querySelector(SELECTORS.retweetButton);
    if (retweetBtn) {
      retweetBtn.click();
      await sleep(500);

      // Look for "Quote" menu item
      const menuItems = document.querySelectorAll('[role="menuitem"]');
      for (const item of menuItems) {
        if (
          item.textContent.includes("Quote") ||
          item.textContent.includes("引用")
        ) {
          item.click();
          await sleep(500);
          break;
        }
      }
    }

    try {
      const result = await chrome.runtime.sendMessage({
        action: "generateQuote",
        tweetText,
      });

      if (result.success) {
        const content = result.data?.data?.content || "";
        if (content) {
          await insertTextIntoCompose(content);
          showToast("引用コメントを生成しました", "success");
        } else {
          showToast("生成結果が空です", "error");
        }
      } else {
        showToast(result.error || "生成に失敗しました", "error");
      }
    } catch (e) {
      showToast("エラーが発生しました", "error");
    } finally {
      btn.classList.remove("xopt-loading");
      btn.disabled = false;
    }
  }

  // ---- Inject buttons into a tweet ----

  function injectButtonsIntoTweet(tweetEl) {
    if (tweetEl.querySelector(".xopt-tweet-btn")) return; // Already injected

    const actionBar = tweetEl.querySelector(SELECTORS.actionBar);
    if (!actionBar) return;

    // Create container
    const container = document.createElement("div");
    container.className = "xopt-btn-container";

    // Reply button
    const replyBtn = createTweetButton("返信", (btn) =>
      handleReply(btn, tweetEl)
    );

    // Quote button
    const quoteBtn = createTweetButton("引用", (btn) =>
      handleQuote(btn, tweetEl)
    );

    container.appendChild(replyBtn);
    container.appendChild(quoteBtn);
    actionBar.appendChild(container);
  }

  // ---- Floating post button + modal ----

  function createFloatingButton() {
    if (document.querySelector(".xopt-floating-btn")) return;

    const btn = document.createElement("button");
    btn.className = "xopt-floating-btn";
    btn.innerHTML = BOLT_ICON_SVG;
    btn.setAttribute("aria-label", "xopt AI投稿");
    btn.addEventListener("click", () => toggleModal());
    document.body.appendChild(btn);
  }

  function toggleModal() {
    const existing = document.querySelector(".xopt-modal-overlay");
    if (existing) {
      existing.remove();
      return;
    }
    createModal();
  }

  function createModal() {
    const dark = isDarkMode();

    const overlay = document.createElement("div");
    overlay.className = "xopt-modal-overlay";
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.remove();
    });

    const modal = document.createElement("div");
    modal.className = `xopt-modal ${dark ? "xopt-dark" : "xopt-light"}`;

    modal.innerHTML = `
      <div class="xopt-modal-header">
        <h3 class="xopt-modal-title">${BOLT_ICON_SVG} xopt AI投稿</h3>
        <button class="xopt-modal-close">&times;</button>
      </div>
      <div class="xopt-modal-body">
        <div class="xopt-form-group">
          <label class="xopt-label">テーマ</label>
          <textarea class="xopt-input xopt-textarea" id="xopt-theme"
            placeholder="投稿のテーマを入力（例: AIエージェントの活用法）"></textarea>
        </div>
        <div class="xopt-form-row">
          <div class="xopt-form-group xopt-form-half">
            <label class="xopt-label">カテゴリ</label>
            <select class="xopt-input xopt-select" id="xopt-category">
              <option value="useful">有益情報</option>
              <option value="opinion">意見・主張</option>
              <option value="experience">体験談</option>
              <option value="question">問いかけ</option>
              <option value="news">ニュース解説</option>
            </select>
          </div>
          <div class="xopt-form-group xopt-form-half">
            <label class="xopt-label">トーン</label>
            <select class="xopt-input xopt-select" id="xopt-tone">
              <option value="auto">自動</option>
              <option value="casual">カジュアル</option>
              <option value="professional">プロフェッショナル</option>
              <option value="provocative">挑戦的</option>
            </select>
          </div>
        </div>
        <button class="xopt-btn xopt-btn-primary" id="xopt-generate-btn">
          AI生成
        </button>
        <div class="xopt-preview" id="xopt-preview" style="display:none">
          <label class="xopt-label">プレビュー</label>
          <div class="xopt-preview-text" id="xopt-preview-text"></div>
          <div class="xopt-preview-actions">
            <button class="xopt-btn xopt-btn-secondary" id="xopt-copy-btn">コピー</button>
            <button class="xopt-btn xopt-btn-primary" id="xopt-insert-btn">コンポーズに挿入</button>
          </div>
        </div>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Event listeners
    modal.querySelector(".xopt-modal-close").addEventListener("click", () => {
      overlay.remove();
    });

    modal
      .querySelector("#xopt-generate-btn")
      .addEventListener("click", handleGeneratePost);

    modal.querySelector("#xopt-copy-btn").addEventListener("click", () => {
      const text = document.getElementById("xopt-preview-text").textContent;
      navigator.clipboard.writeText(text);
      showToast("コピーしました", "success");
    });

    modal.querySelector("#xopt-insert-btn").addEventListener("click", async () => {
      const text = document.getElementById("xopt-preview-text").textContent;
      overlay.remove();

      // Click the native compose button if available
      const composeBtn = document.querySelector(
        '[data-testid="SideNav_NewTweet_Button"]'
      );
      if (composeBtn) {
        composeBtn.click();
        await sleep(500);
      }

      await insertTextIntoCompose(text);
      showToast("コンポーズに挿入しました", "success");
    });
  }

  async function handleGeneratePost() {
    const theme = document.getElementById("xopt-theme").value.trim();
    if (!theme) {
      showToast("テーマを入力してください", "error");
      return;
    }

    const category = document.getElementById("xopt-category").value;
    const tone = document.getElementById("xopt-tone").value;
    const btn = document.getElementById("xopt-generate-btn");
    const preview = document.getElementById("xopt-preview");
    const previewText = document.getElementById("xopt-preview-text");

    btn.disabled = true;
    btn.textContent = "生成中...";
    preview.style.display = "none";

    try {
      const result = await chrome.runtime.sendMessage({
        action: "generatePost",
        theme,
        category,
        tone,
      });

      if (result.success) {
        const content = result.data?.data?.content || "";
        if (content) {
          previewText.textContent = content;
          preview.style.display = "block";
          showToast("投稿を生成しました", "success");
        } else {
          showToast("生成結果が空です", "error");
        }
      } else {
        showToast(result.error || "生成に失敗しました", "error");
      }
    } catch (e) {
      showToast("エラーが発生しました", "error");
    } finally {
      btn.disabled = false;
      btn.textContent = "AI生成";
    }
  }

  // ---- MutationObserver for dynamic content ----

  function scanAndInject() {
    const tweets = document.querySelectorAll(SELECTORS.tweet);
    tweets.forEach(injectButtonsIntoTweet);
  }

  function startObserver() {
    const observer = new MutationObserver((mutations) => {
      let shouldScan = false;
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          shouldScan = true;
          break;
        }
      }
      if (shouldScan) {
        // Debounce scanning
        clearTimeout(startObserver._timer);
        startObserver._timer = setTimeout(scanAndInject, 300);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  // ---- Initialization ----

  async function init() {
    // Check if API key is set
    try {
      const result = await chrome.runtime.sendMessage({ action: "getApiKey" });
      if (!result.hasKey) {
        showToast(
          "xopt APIキーが未設定です。拡張機能アイコンをクリックして設定してください",
          "info"
        );
      }
    } catch (e) {
      // Extension context may not be ready
    }

    // Initial scan
    scanAndInject();

    // Start observing
    startObserver();

    // Create floating button
    createFloatingButton();
  }

  // Start when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
