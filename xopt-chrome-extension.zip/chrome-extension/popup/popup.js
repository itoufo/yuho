/**
 * xopt Chrome Extension — Popup Script
 * API key management and connection testing
 */

document.addEventListener("DOMContentLoaded", async () => {
  const apiKeyInput = document.getElementById("api-key");
  const saveBtn = document.getElementById("save-btn");
  const toggleBtn = document.getElementById("toggle-visibility");
  const statusEl = document.getElementById("status");
  const creditInfo = document.getElementById("credit-info");
  const creditValue = document.getElementById("credit-value");

  // Load saved API key
  const stored = await chrome.storage.local.get(["xopt_api_key"]);
  if (stored.xopt_api_key) {
    apiKeyInput.value = stored.xopt_api_key;
  }

  // Toggle password visibility
  toggleBtn.addEventListener("click", () => {
    const isPassword = apiKeyInput.type === "password";
    apiKeyInput.type = isPassword ? "text" : "password";
  });

  // Save and test
  saveBtn.addEventListener("click", async () => {
    const apiKey = apiKeyInput.value.trim();

    // Validate format
    if (!apiKey) {
      showStatus("APIキーを入力してください", "error");
      return;
    }

    if (!apiKey.startsWith("xopt_")) {
      showStatus('APIキーは "xopt_" で始まる必要があります', "error");
      return;
    }

    // Save
    await chrome.storage.local.set({ xopt_api_key: apiKey });

    // Test connection
    saveBtn.disabled = true;
    saveBtn.textContent = "接続テスト中...";
    showStatus("接続テスト中...", "loading");

    try {
      const result = await chrome.runtime.sendMessage({
        action: "testConnection",
        apiKey,
      });

      if (result.success) {
        showStatus("接続成功", "success");

        // Show credit balance if available
        if (result.data?.credits) {
          creditInfo.style.display = "block";
          creditValue.textContent = `${result.data.credits.remaining} クレジット`;
        } else {
          creditInfo.style.display = "block";
          creditValue.textContent = "取得成功";
        }
      } else {
        showStatus(result.error || "接続に失敗しました", "error");
        creditInfo.style.display = "none";
      }
    } catch (e) {
      showStatus("エラーが発生しました", "error");
      creditInfo.style.display = "none";
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = "保存して接続テスト";
    }
  });

  function showStatus(message, type) {
    statusEl.style.display = "block";
    statusEl.textContent = message;
    statusEl.className = `status status-${type}`;
  }
});
